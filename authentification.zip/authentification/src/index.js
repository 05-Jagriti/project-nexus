import exp from "express";
import pathh from "path";
import bcr from "bcrypt";
import collection from "./config.js";

const app = exp();

app.set('view engine', 'ejs');
app.use(exp.static("public"));
app.use(exp.json());
app.use(exp.urlencoded({extended:false}));

app.get("/", (req,res)=>{
    res.render('login');
});

app.get("/signup", (req,res)=>{
    res.render('signup');
});

app.post("/signup",async (req,res)=>{
    const data = {
        name : req.body.username,
        password : req.body.password
    }

    const exist = await collection.findOne({name : data.name});
    if(exist){
        res.send("User already exist. Plese choose a different username.");
    }else{
        const saltRound = 10;
        const hashPass = await bcr.hash(data.password, saltRound);
        data.password = hashPass;
        const userdata = await collection.insertMany(data);
        console.log(userdata);
    }  
});

app.post("/login",async (req,res)=>{
    try {
        const check = await collection.findOne({name : req.body.username});
        if (!check) {
            res.send("User cannot found.");
        }

        const matchPass = await bcr.compare(req.body.password , check.password);
        if (matchPass) {
            res.render("home");
        }else{
            res.send("Wrong password.");
        }
    } catch{
        res.send("Wrong details");
    }
});

const port = 4000;
app.listen(port , ()=>{
    console.log(`Server is running on port ${port}`);
});
